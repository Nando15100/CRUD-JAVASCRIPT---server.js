 function confirmarSaida() {
      return confirm('Tem certeza que deseja sair e voltar à página inicial?');
    }